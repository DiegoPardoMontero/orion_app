/**
 * Comportamiento del portafolio. Todo es progresivo: sin JavaScript la
 * página se ve y se navega igual, sólo sin movimiento.
 *
 *   1. Recuerda el idioma elegido.
 *   2. Marca en el menú la sección que se está leyendo.
 *   3. Entrada suave de cada sección al aparecer.
 *
 * Las animaciones viven aparte, en motion.js.
 */
(function () {
  'use strict';

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ── 1. Idioma ──────────────────────────────────────────────────────── */

  var KEY = 'dpm-portfolio-lang';
  document.querySelectorAll('.lang-link').forEach(function (link) {
    link.addEventListener('click', function () {
      try {
        localStorage.setItem(KEY, link.dataset.lang);
      } catch (e) {
        /* Modo privado o almacenamiento bloqueado: el enlace navega igual. */
      }
    });
  });

  /* ── 2. Sección activa en el menú ───────────────────────────────────── */

  (function navHighlight() {
    var links = {};
    document.querySelectorAll('[data-nav]').forEach(function (a) { links[a.dataset.nav] = a; });
    var sections = document.querySelectorAll('.section[id]');
    if (!sections.length || !('IntersectionObserver' in window)) return;

    var visible = new Set();
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) visible.add(entry.target.id);
        else visible.delete(entry.target.id);
      });
      var current = null;
      sections.forEach(function (s) { if (visible.has(s.id) && !current) current = s.id; });
      Object.keys(links).forEach(function (id) {
        if (id === current) links[id].setAttribute('aria-current', 'location');
        else links[id].removeAttribute('aria-current');
      });
    }, { rootMargin: '-45% 0px -50% 0px' });

    sections.forEach(function (s) { observer.observe(s); });
  })();

  /* ── 3. Entrada al aparecer ─────────────────────────────────────────── */

  (function reveal() {
    var targets = document.querySelectorAll('[data-reveal]');
    if (!('IntersectionObserver' in window)) {
      targets.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    targets.forEach(function (el) { observer.observe(el); });
  })();

})();
