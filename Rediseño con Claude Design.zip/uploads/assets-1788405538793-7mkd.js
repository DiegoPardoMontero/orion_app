/**
 * Las animaciones del sitio, todas de ingeniería de datos y todas con las
 * mismas reglas: se dibujan en SVG desde la posición real de los elementos,
 * corren sólo con la sección en pantalla y la pestaña visible, se rehacen al
 * cambiar el tamaño de la ventana, y con `prefers-reduced-motion` se quedan
 * en una imagen fija.
 *
 * Cada escena cuenta algo que está en el CV, no adorno:
 *
 *   1. Trayectoria (hero): las cuatro etapas en producción, a escala real de
 *      meses, con el puesto actual todavía latiendo.
 *   2. El pipeline (Habilidades): las herramientas de cada etapa del proceso.
 *   3. La corrida del framework de migración (Habilidades): la arquitectura
 *      construida en Diametral, con su reintento de validaciones.
 *   4. Los resultados medidos (cierre): las cifras del CV, contando hasta su
 *      valor, cada una con su origen.
 *   5. La escalera de certificaciones (Formación): las tres con fecha y las
 *      dos en curso.
 *   6. La línea de tiempo (Experiencia): el riel se pinta con el scroll.
 *   7. La tinta de las tarjetas (Case studies): sigue al cursor.
 *
 * Los colores salen de la paleta "Proceso" (ver assets/css/portfolio.css):
 * las tintas de estado nunca van solas, siempre con etiqueta e icono.
 */
(function () {
  'use strict';

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var NS = 'http://www.w3.org/2000/svg';

  /* ── Utilidades comunes ─────────────────────────────────────────────── */

  function el(name, attrs) {
    var node = document.createElementNS(NS, name);
    for (var key in attrs) {
      if (Object.prototype.hasOwnProperty.call(attrs, key)) node.setAttribute(key, attrs[key]);
    }
    return node;
  }

  function clear(node) {
    while (node.firstChild) node.removeChild(node.firstChild);
  }

  var clamp = function (v, min, max) {
    return v < min ? min : v > max ? max : v;
  };

  var easeInOut = function (p) {
    return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
  };

  /**
   * Da vida a una escena: la mide, la redibuja cada cuadro mientras se vea, y
   * la vuelve a medir cuando cambia de tamaño. `scene.measure(box)` arma el
   * SVG; `scene.draw(time)` pinta el instante `time` del ciclo.
   */
  function run(root, scene) {
    var elapsed = 0;
    var last = 0;
    var running = false;
    var pendingResize = false;

    function measure() {
      var box = root.getBoundingClientRect();
      if (!box.width || !box.height) return;
      scene.measure(box);
      scene.draw(elapsed);
    }

    function frame(now) {
      if (!running) return;
      if (last) elapsed += Math.min(now - last, 64);
      last = now;
      scene.draw(elapsed);
      requestAnimationFrame(frame);
    }

    function start() {
      if (running || reduced) return;
      running = true;
      last = 0;
      requestAnimationFrame(frame);
    }

    function stop() { running = false; }

    measure();

    if (typeof ResizeObserver === 'function') {
      new ResizeObserver(function () {
        if (pendingResize) return;
        pendingResize = true;
        requestAnimationFrame(function () { pendingResize = false; measure(); });
      }).observe(root);
    } else {
      window.addEventListener('resize', measure);
    }

    if (reduced) {
      /* Una sola foto, en un momento representativo del ciclo. */
      scene.draw(scene.still || 0);
      return;
    }

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        if (entries[0].isIntersecting) start(); else stop();
      }, { threshold: 0.15 }).observe(root);
    } else {
      start();
    }

    document.addEventListener('visibilitychange', function () {
      if (document.hidden) stop();
      else if (root.getBoundingClientRect().top < window.innerHeight) start();
    });
  }
  /* ── 1. La trayectoria en producción ────────────────────────────────── */

  (function career() {
    var root = document.querySelector('[data-career]');
    if (!root) return;
    var svg = root.querySelector('.career-plot');
    if (!svg) return;

    var spans;
    try { spans = JSON.parse(root.dataset.spans); } catch (e) { return; }
    if (!spans || !spans.length) return;

    /* 'YYYY-MM' a meses absolutos, para medir cada etapa en la misma regla. */
    function months(value) {
      var parts = String(value).split('-');
      return Number(parts[0]) * 12 + (Number(parts[1]) - 1);
    }
    var asOf = months(root.dataset.asOf);
    var first = months(spans[0].from);
    var lastEnd = Math.max.apply(null, spans.map(function (s0) {
      return s0.to ? months(s0.to) : asOf;
    }));
    var total = Math.max(1, lastEnd - first);

    var BAR = 12;
    var GROW = 620;      /* lo que tarda en dibujarse cada etapa */
    var STAGGER = 150;

    var bars = [];
    var live = null;
    var years = [];

    var scene = {
      still: 4000,
      measure: function (box) {
        var W = box.width;
        var H = svg.clientHeight || 62;
        svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
        clear(svg);
        bars = [];
        years = [];

        var top = 6;
        /* Se reserva el borde derecho para que el punto del puesto actual no
           quede cortado. */
        var plot = W - 9;
        spans.forEach(function (span, i) {
          var from = months(span.from) - first;
          var to = (span.to ? months(span.to) : asOf) - first;
          var x = (from / total) * plot;
          var width = Math.max(6, ((to - from) / total) * plot - 2);
          var rect = el('rect', {
            class: 'career-span ink-' + span.ink,
            x: x.toFixed(1), y: top, height: BAR, rx: 2, width: 0,
          });
          svg.appendChild(rect);
          bars.push({ node: rect, width: width, delay: i * STAGGER, x: x });
          if (!span.to) live = { x: x + width, y: top + BAR / 2 };
        });

        /* Una marca por año, como eje. */
        var startYear = Math.ceil(first / 12);
        for (var y = startYear; y <= Math.floor(lastEnd / 12); y++) {
          var at = ((y * 12 - first) / total) * plot;
          var tick = el('line', { class: 'career-tick', x1: at, x2: at, y1: top + BAR + 4, y2: top + BAR + 8 });
          /* El año no se sale por los bordes: en los extremos se ancla adentro. */
          var edge = at < 14 ? 'start' : at > W - 14 ? 'end' : 'middle';
          var text = el('text', {
            class: 'career-year', y: top + BAR + 20, 'text-anchor': edge,
            x: edge === 'start' ? 0 : edge === 'end' ? W : at,
          });
          text.textContent = String(y);
          svg.appendChild(tick);
          svg.appendChild(text);
          years.push(text);
        }

        if (live) {
          live.halo = el('circle', { class: 'career-live-halo', cx: live.x, cy: live.y, r: 7 });
          live.dot = el('circle', { class: 'career-live', cx: live.x, cy: live.y, r: 3.5 });
          svg.appendChild(live.halo);
          svg.appendChild(live.dot);
        }
      },
      draw: function (time) {
        /* Sin ciclo: la barra se dibuja una vez y se queda; lo único que sigue
           moviéndose es el punto del puesto actual. */
        var t = time;
        bars.forEach(function (bar) {
          var p = clamp((t - bar.delay) / GROW, 0, 1);
          bar.node.setAttribute('width', (bar.width * easeInOut(p)).toFixed(1));
        });
        if (live) {
          /* El puesto actual sigue latiendo: la corrida no ha terminado. */
          var shown = t > GROW + STAGGER * (bars.length - 1);
          var pulse = shown ? (Math.sin(t / 420) + 1) / 2 : 0;
          live.dot.style.opacity = shown ? '1' : '0';
          live.halo.style.opacity = (0.10 + pulse * 0.22).toFixed(3);
          live.halo.setAttribute('r', (6 + pulse * 3).toFixed(2));
        }
      },
    };

    run(root, scene);
  })();

  /* ── 2. El pipeline corriendo ───────────────────────────────────────── */

  (function pipeline() {
    var root = document.querySelector('[data-pipeline]');
    if (!root) return;
    var svg = root.querySelector('.pipeline-flow');
    var stages = Array.prototype.slice.call(root.querySelectorAll('[data-stage]'));
    var gaps = Array.prototype.slice.call(root.querySelectorAll('.stage-gap'));
    if (!svg || stages.length < 2 || gaps.length !== stages.length - 1) return;

    /* Tiempos del ciclo, en milisegundos. */
    var LEAD = 420;      // el primer pulso, antes de que salga nada
    var TRAVEL = 780;    // lo que tarda un paquete en cruzar un tramo
    var DWELL = 300;     // pausa dentro de cada etapa
    var TAIL = 1500;     // respiro al final, con el pipeline aún caliente
    var PULSE = 620;     // duración del destello de una etapa
    var FADE = 520;      // apagado de los conectores al cerrar el ciclo

    var n = stages.length - 1;                       // tramos
    var CYCLE = LEAD + n * (TRAVEL + DWELL) + TAIL;

    var segments = [];   // geometría + nodos SVG de cada tramo
    var running = false;
    var elapsed = 0;
    var last = 0;
    var pending = false;

    function rectIn(el, base) {
      var r = el.getBoundingClientRect();
      return { x: r.left - base.left, y: r.top - base.top, w: r.width, h: r.height };
    }

    /** Rehace los conectores a partir de la posición real de los iconos. */
    function measure() {
      var base = root.getBoundingClientRect();
      if (!base.width) return;
      svg.setAttribute('viewBox', '0 0 ' + base.width + ' ' + base.height);
      while (svg.firstChild) svg.removeChild(svg.firstChild);
      segments = [];

      for (var i = 0; i < n; i++) {
        var icon = stages[i].querySelector('.stage-icon-box');
        var nextIcon = stages[i + 1].querySelector('.stage-icon-box');
        var arrow = gaps[i].querySelector('.ui-icon');
        if (!icon || !nextIcon || !arrow) continue;

        var a = rectIn(icon, base);
        var b = rectIn(nextIcon, base);
        var g = rectIn(gaps[i], base);
        var arrowBox = rectIn(arrow, base);
        /* En escritorio las etapas van en fila; en móvil, en columna. */
        var horizontal = Math.abs(b.x - a.x) > Math.abs(b.y - a.y);

        var from = horizontal
          ? { x: a.x + a.w + 10, y: a.y + a.h / 2 }
          : { x: a.x + a.w / 2, y: g.y + 2 };
        var to = horizontal
          ? { x: arrowBox.x - 6, y: a.y + a.h / 2 }
          : { x: a.x + a.w / 2, y: arrowBox.y - 6 };

        var length = Math.hypot(to.x - from.x, to.y - from.y);
        if (length < 8) continue;

        var d = 'M' + from.x + ' ' + from.y + ' L' + to.x + ' ' + to.y;
        /* El color vive en portfolio.css (.flow-*): var() no es fiable en
           atributos de presentación, así que aquí sólo va la geometría. */
        var base_ = el('path', { d: d, class: 'flow-rail' });
        var lit = el('path', {
          d: d, class: 'flow-lit',
          'stroke-dasharray': length, 'stroke-dashoffset': length,
        });
        var halo = el('circle', { class: 'flow-halo', r: '7' });
        var dot = el('circle', { class: 'flow-dot', r: '3' });
        lit.style.opacity = halo.style.opacity = dot.style.opacity = '0';

        svg.appendChild(base_);
        svg.appendChild(lit);
        svg.appendChild(halo);
        svg.appendChild(dot);
        segments.push({ from: from, to: to, length: length, lit: lit, dot: dot, halo: halo, gap: gaps[i] });
      }
      draw(elapsed);
    }

    /** Dibuja el estado del ciclo en el instante `time`. */
    function draw(time) {
      var t = ((time % CYCLE) + CYCLE) % CYCLE;

      /* Cada etapa destella cuando el paquete llega a ella. */
      stages.forEach(function (stage, i) {
        var arrival = i === 0 ? 0 : LEAD + (i - 1) * (TRAVEL + DWELL) + TRAVEL;
        var since = t - arrival;
        var pulse = since >= 0 && since <= PULSE ? Math.sin(Math.PI * (since / PULSE)) : 0;
        stage.style.setProperty('--pulse', pulse.toFixed(3));
      });

      segments.forEach(function (seg, i) {
        var start = LEAD + i * (TRAVEL + DWELL);
        var p = (t - start) / TRAVEL;
        var tailStart = CYCLE - FADE;

        if (p >= 0 && p <= 1) {
          /* Tramo en curso: la línea se enciende detrás del paquete. */
          var eased = easeInOut(p);
          var x = seg.from.x + (seg.to.x - seg.from.x) * eased;
          var y = seg.from.y + (seg.to.y - seg.from.y) * eased;
          seg.lit.setAttribute('stroke-dashoffset', seg.length * (1 - eased));
          seg.lit.style.opacity = '1';
          seg.dot.setAttribute('cx', x); seg.dot.setAttribute('cy', y); seg.dot.style.opacity = '1';
          seg.halo.setAttribute('cx', x); seg.halo.setAttribute('cy', y); seg.halo.style.opacity = '0.18';
          seg.gap.style.setProperty('--lit', eased.toFixed(3));
        } else if (p > 1) {
          /* Ya pasó: queda tibio hasta que el ciclo se apaga. */
          var cool = t > tailStart ? Math.max(0, 1 - (t - tailStart) / FADE) : 1;
          seg.lit.setAttribute('stroke-dashoffset', '0');
          seg.lit.style.opacity = (0.38 * cool).toFixed(3);
          seg.dot.style.opacity = '0';
          seg.halo.style.opacity = '0';
          seg.gap.style.setProperty('--lit', cool.toFixed(3));
        } else {
          /* Todavía no le toca. */
          seg.lit.setAttribute('stroke-dashoffset', seg.length);
          seg.lit.style.opacity = '0';
          seg.dot.style.opacity = '0';
          seg.halo.style.opacity = '0';
          seg.gap.style.setProperty('--lit', '0');
        }
      });
    }

    function frame(now) {
      if (!running) return;
      if (last) elapsed += Math.min(now - last, 64);  /* pestaña de vuelta: sin saltos */
      last = now;
      draw(elapsed);
      requestAnimationFrame(frame);
    }

    function start() {
      if (running || reduced) return;
      running = true;
      last = 0;
      requestAnimationFrame(frame);
    }

    function stop() {
      running = false;
    }

    measure();

    if (typeof ResizeObserver === 'function') {
      new ResizeObserver(function () {
        /* Una sola remedida por frame, aunque el navegador dispare varias. */
        if (pending) return;
        pending = true;
        requestAnimationFrame(function () { pending = false; measure(); });
      }).observe(root);
    } else {
      window.addEventListener('resize', measure);
    }

    if (reduced) return;   /* Conectores y flechas sí; movimiento no. */

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        entries[0].isIntersecting ? start() : stop();
      }, { threshold: 0.15 }).observe(root);
    } else {
      start();
    }

    document.addEventListener('visibilitychange', function () {
      if (document.hidden) stop();
      else if (root.getBoundingClientRect().top < window.innerHeight) start();
    });
  })();
  /* ── 3. La corrida del DAG ──────────────────────────────────────────── */

  (function dagRun() {
    var root = document.querySelector('[data-dag]');
    if (!root) return;
    var svg = root.querySelector('.dag-plot');
    if (!svg) return;

    var labels = (root.dataset.nodes || '').split('|');

    /* El grafo del framework: la tabla de control dispara la extracción, el
       Bronze abre en las tres estrategias de carga, todas confluyen en las
       validaciones y de ahí salen los marts y la auditoría. */
    var LAYOUT = [
      { x: 0.02, y: 0.50 },
      { x: 0.16, y: 0.50 },
      { x: 0.31, y: 0.50 },
      { x: 0.49, y: 0.07 },
      { x: 0.49, y: 0.50 },
      { x: 0.49, y: 0.93 },
      { x: 0.67, y: 0.50 },
      { x: 0.83, y: 0.50 },
      { x: 0.97, y: 0.50 },
    ];
    /* En vertical el grafo se reordena: la cadena baja por la izquierda y las
       tres estrategias de carga se abren en abanico, con sitio para su
       etiqueta al lado. */
    var LAYOUT_VERTICAL = [
      { x: 0.20, y: 0.02 },
      { x: 0.20, y: 0.14 },
      { x: 0.20, y: 0.27 },
      { x: 0.40, y: 0.41 },
      { x: 0.40, y: 0.53 },
      { x: 0.40, y: 0.65 },
      { x: 0.20, y: 0.79 },
      { x: 0.20, y: 0.90 },
      { x: 0.20, y: 1.00 },
    ];
    var EDGES = [
      [0, 1], [1, 2],
      [2, 3], [2, 4], [2, 5],
      [3, 6], [4, 6], [5, 6],
      [6, 7], [7, 8],
    ];

    /* El calendario de la corrida. Las validaciones fallan una vez y
       reintentan: es la parte del trabajo que nadie pone en el CV. */
    var SCHEDULE = [
      { start: 0, run: 520 },
      { start: 760, run: 820 },
      { start: 1820, run: 700 },
      { start: 2760, run: 900 },
      { start: 2760, run: 760 },
      { start: 2760, run: 640 },
      { start: 3900, run: 620, retry: 520 },
      { start: 5900, run: 700 },
      { start: 6840, run: 520 },
    ];
    SCHEDULE.forEach(function (task) {
      task.total = task.run + (task.retry ? task.retry + task.run : 0);
      task.done = task.start + task.total;
    });
    var CYCLE = Math.max.apply(null, SCHEDULE.map(function (t) { return t.done; })) + 2600;

    var R = 11;
    var points = [];
    var nodes = [];
    var edges = [];

    var scene = {
      still: CYCLE - 1200,   /* la foto quieta: la corrida ya terminada */
      measure: function (box) {
        var W = box.width;
        var H = svg.clientHeight || 150;
        var vertical = W < 560;
        svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
        clear(svg);
        points = [];
        nodes = [];
        edges = [];

        var padX = vertical ? 14 : 18;
        var padY = vertical ? 16 : 24;
        (vertical ? LAYOUT_VERTICAL : LAYOUT).forEach(function (pos) {
          points.push({
            x: padX + pos.x * (W - padX * 2),
            y: padY + pos.y * (H - padY * 2),
          });
        });

        EDGES.forEach(function (pair) {
          var a = points[pair[0]];
          var b = points[pair[1]];
          var dx = b.x - a.x;
          var dy = b.y - a.y;
          var len = Math.hypot(dx, dy) || 1;
          var from = { x: a.x + (dx / len) * (R + 4), y: a.y + (dy / len) * (R + 4) };
          var to = { x: b.x - (dx / len) * (R + 6), y: b.y - (dy / len) * (R + 6) };
          var d = 'M' + from.x + ' ' + from.y + ' L' + to.x + ' ' + to.y;
          var length = Math.hypot(to.x - from.x, to.y - from.y);
          var rail = el('path', { class: 'dag-edge', d: d });
          var lit = el('path', {
            class: 'dag-edge-lit', d: d,
            'stroke-dasharray': length, 'stroke-dashoffset': length,
          });
          var token = el('circle', { class: 'dag-token', r: 2.6 });
          token.style.opacity = '0';
          svg.appendChild(rail);
          svg.appendChild(lit);
          svg.appendChild(token);
          edges.push({ pair: pair, from: from, to: to, length: length, lit: lit, token: token });
        });

        points.forEach(function (pos, i) {
          var group = el('g', { class: 'dag-node' });
          var ring = el('circle', { class: 'dag-ring', cx: pos.x, cy: pos.y, r: R });
          var core = el('circle', { class: 'dag-core', cx: pos.x, cy: pos.y, r: R - 4 });
          var check = el('path', {
            class: 'dag-check',
            d: 'M' + (pos.x - 4.2) + ' ' + pos.y + ' L' + (pos.x - 1.2) + ' ' + (pos.y + 3.2) +
               ' L' + (pos.x + 4.4) + ' ' + (pos.y - 3.4),
          });
          /* En vertical la etiqueta va al lado del nodo; sólo se mete hacia
             adentro si el nodo quedó en la mitad derecha. */
          var inner = vertical && pos.x > W * 0.55;
          var label = labels[i] || '';
          var text = el('text', {
            class: 'dag-label',
            x: vertical ? (inner ? pos.x - R - 10 : pos.x + R + 10) : pos.x,
            y: vertical ? pos.y + 4 : pos.y + R + 15,
            'text-anchor': vertical ? (inner ? 'end' : 'start') : 'middle',
          });
          /* En horizontal hay poco ancho por nodo: las etiquetas largas se
             parten en dos renglones por el espacio más cercano al centro. */
          var cut = -1;
          if (!vertical && label.length > 11) {
            var middle = label.length / 2;
            for (var c = 0; c < label.length; c++) {
              if (label.charAt(c) === ' ' && (cut < 0 || Math.abs(c - middle) < Math.abs(cut - middle))) cut = c;
            }
          }
          if (cut > 0) {
            var top = el('tspan', { x: text.getAttribute('x'), dy: 0 });
            top.textContent = label.slice(0, cut);
            var bottom = el('tspan', { x: text.getAttribute('x'), dy: 13 });
            bottom.textContent = label.slice(cut + 1);
            text.appendChild(top);
            text.appendChild(bottom);
          } else {
            text.textContent = label;
          }
          group.appendChild(ring);
          group.appendChild(core);
          group.appendChild(check);
          group.appendChild(text);
          svg.appendChild(group);
          nodes.push({ ring: ring, core: core, check: check, group: group });
        });
      },
      draw: function (time) {
        var t = ((time % CYCLE) + CYCLE) % CYCLE;

        nodes.forEach(function (node, i) {
          var task = SCHEDULE[i];
          var state = 'queued';
          var spin = 0;

          if (t >= task.done) {
            state = 'done';
          } else if (t >= task.start) {
            var since = t - task.start;
            if (task.retry && since >= task.run && since < task.run + task.retry) state = 'retry';
            else state = 'running';
            spin = since;
          }

          node.group.setAttribute('class', 'dag-node is-' + state);
          if (state === 'running' || state === 'retry') {
            var perimeter = 2 * Math.PI * R;
            node.ring.setAttribute('stroke-dasharray', (perimeter * 0.3).toFixed(1) + ' ' + (perimeter * 0.7).toFixed(1));
            node.ring.setAttribute('stroke-dashoffset', (-spin / (state === 'retry' ? 3 : 5)).toFixed(1));
          } else {
            node.ring.removeAttribute('stroke-dasharray');
            node.ring.removeAttribute('stroke-dashoffset');
          }
          /* El visto se traza en vez de aparecer de golpe. */
          var drawn = state === 'done' ? clamp((t - task.done) / 260, 0, 1) : 0;
          node.check.style.opacity = drawn > 0 ? '1' : '0';
          node.check.setAttribute('stroke-dasharray', '14');
          node.check.setAttribute('stroke-dashoffset', (14 * (1 - drawn)).toFixed(2));
        });

        edges.forEach(function (edge) {
          var source = SCHEDULE[edge.pair[0]];
          var target = SCHEDULE[edge.pair[1]];
          var span = Math.max(220, target.start - source.done);
          var p = (t - source.done) / span;

          if (p >= 0 && p <= 1) {
            var eased = easeInOut(p);
            edge.lit.setAttribute('stroke-dashoffset', (edge.length * (1 - eased)).toFixed(1));
            edge.lit.style.opacity = '1';
            edge.token.setAttribute('cx', edge.from.x + (edge.to.x - edge.from.x) * eased);
            edge.token.setAttribute('cy', edge.from.y + (edge.to.y - edge.from.y) * eased);
            edge.token.style.opacity = '1';
          } else if (p > 1) {
            edge.lit.setAttribute('stroke-dashoffset', '0');
            edge.lit.style.opacity = t > CYCLE - 700 ? String(clamp((CYCLE - t) / 700, 0, 1) * 0.55) : '0.55';
            edge.token.style.opacity = '0';
          } else {
            edge.lit.setAttribute('stroke-dashoffset', edge.length);
            edge.lit.style.opacity = '0';
            edge.token.style.opacity = '0';
          }
        });
      },
    };

    run(root, scene);
  })();

  /* ── 4. Los resultados medidos ──────────────────────────────────────── */

  (function impactBand() {
    var root = document.querySelector('[data-impact-band]');
    if (!root) return;
    var tiles = Array.prototype.slice.call(root.querySelectorAll('.impact-tile'));
    if (!tiles.length) return;

    /* Sin movimiento, las cifras se muestran tal cual están en el HTML. */
    if (reduced || !('IntersectionObserver' in window)) {
      tiles.forEach(function (tile) { tile.classList.add('is-shown'); });
      return;
    }

    var COUNT_MS = 900;
    var STAGGER = 150;

    tiles.forEach(function (tile) {
      var value = tile.querySelector('.impact-value');
      if (value && value.dataset.count) value.textContent = (value.dataset.prefix || '') + '0' + (value.dataset.suffix || '');
    });

    function play() {
      var started = 0;
      function frame(now) {
        if (!started) started = now;
        var elapsed = now - started;
        var pending = false;
        tiles.forEach(function (tile, i) {
          var p = clamp((elapsed - i * STAGGER) / COUNT_MS, 0, 1);
          if (p > 0) tile.classList.add('is-shown');
          if (p < 1) pending = true;
          var value = tile.querySelector('.impact-value');
          if (!value || !value.dataset.count) return;
          /* La cifra sube hasta su valor real; el signo y la unidad no cambian. */
          var target = Number(value.dataset.count);
          var shown = Math.round(target * easeInOut(p));
          value.textContent = (value.dataset.prefix || '') + shown + (value.dataset.suffix || '');
        });
        if (pending) requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    }

    var observer = new IntersectionObserver(function (entries) {
      if (!entries[0].isIntersecting) return;
      observer.disconnect();
      play();
    }, { threshold: 0.4 });
    observer.observe(root);
  })();

  /* ── 5. La escalera de certificaciones ──────────────────────────────── */

  (function certPath() {
    var root = document.querySelector('[data-cert-path]');
    if (!root) return;
    var svg = root.querySelector('.cert-path-plot');
    if (!svg) return;

    var steps;
    try { steps = JSON.parse(root.dataset.steps); } catch (e) { return; }
    if (!steps || steps.length < 2) return;
    var pendingLabel = root.dataset.pending || '';

    var DRAW = 2200;     /* lo que tarda en subir toda la escalera */

    var line, dots = [], length = 0;

    var scene = {
      still: DRAW + 900,
      measure: function (box) {
        var W = box.width;
        var H = svg.clientHeight || 132;
        svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
        clear(svg);
        dots = [];

        var padX = 6;
        var baseY = H - 22;
        var rise = (H - 54) / (steps.length - 1);
        var stepW = (W - padX * 2) / steps.length;

        /* Un peldaño por certificación: se avanza y se sube. */
        var d = 'M' + padX + ' ' + baseY;
        var points = [];
        steps.forEach(function (step, i) {
          var x = padX + stepW * (i + 0.75);
          var y = baseY - rise * i;
          d += ' L' + x.toFixed(1) + ' ' + y.toFixed(1);
          points.push({ x: x, y: y, step: step });
          if (i < steps.length - 1) d += ' L' + x.toFixed(1) + ' ' + (y - rise).toFixed(1);
        });

        var rail = el('path', { class: 'cert-rail', d: d });
        svg.appendChild(rail);
        line = el('path', { class: 'cert-line', d: d });
        svg.appendChild(line);
        length = line.getTotalLength ? line.getTotalLength() : 1;
        line.setAttribute('stroke-dasharray', length);
        line.setAttribute('stroke-dashoffset', length);

        points.forEach(function (point) {
          var group = el('g', {
            class: 'cert-step ink-' + point.step.ink + (point.step.pending ? ' is-pending' : ''),
          });
          var halo = el('circle', { class: 'cert-halo', cx: point.x, cy: point.y, r: 9 });
          var dot = el('circle', { class: 'cert-dot', cx: point.x, cy: point.y, r: 4.5 });
          /* El último peldaño rotula hacia adentro para no salirse del marco. */
          var toLeft = point.x > W * 0.7;
          var name = el('text', {
            class: 'cert-name',
            x: toLeft ? point.x - 9 : point.x + 9,
            y: point.y - 7,
            'text-anchor': toLeft ? 'end' : 'start',
          });
          name.textContent = point.step.pending ? pendingLabel : (point.step.short || point.step.name);
          var year = el('text', { class: 'cert-year', x: point.x, y: baseY + 16, 'text-anchor': 'middle' });
          year.textContent = point.step.year;
          group.appendChild(halo);
          group.appendChild(dot);
          group.appendChild(name);
          group.appendChild(year);
          svg.appendChild(group);
          dots.push({ group: group, halo: halo, at: point.x, pending: !!point.step.pending });
        });
      },
      draw: function (time) {
        /* Se sube una sola vez; después sólo late la certificación en curso. */
        var t = time;
        var p = clamp(t / DRAW, 0, 1);
        var eased = easeInOut(p);
        line.setAttribute('stroke-dashoffset', (length * (1 - eased)).toFixed(1));

        dots.forEach(function (dot, i) {
          /* Cada peldaño aparece cuando la línea llega a él. */
          var reach = (i + 0.8) / dots.length;
          var shown = clamp((eased - reach) * 6, 0, 1);
          dot.group.style.opacity = shown.toFixed(3);
          if (dot.pending && shown > 0.9) {
            /* La que está en curso late en vez de quedarse quieta. */
            var pulse = (Math.sin(t / 380) + 1) / 2;
            dot.halo.style.opacity = (0.12 + pulse * 0.3).toFixed(3);
            dot.halo.setAttribute('r', (7 + pulse * 3).toFixed(2));
          } else {
            dot.halo.style.opacity = '0.14';
          }
        });
      },
    };

    run(root, scene);
  })();

  /* ── 6. La experiencia como línea de tiempo ─────────────────────────── */

  (function timeline() {
    var list = document.querySelector('[data-timeline]');
    if (!list) return;
    var roles = list.querySelectorAll('[data-role]');
    if (reduced) {
      list.style.setProperty('--progress', '1');
      Array.prototype.forEach.call(roles, function (r) { r.style.setProperty('--past', '1'); });
      return;
    }

    var ticking = false;

    function update() {
      ticking = false;
      var rect = list.getBoundingClientRect();
      /* La línea de lectura va algo más arriba del centro de la ventana. */
      var line = window.innerHeight * 0.55;
      list.style.setProperty('--progress', clamp((line - rect.top) / rect.height, 0, 1).toFixed(3));
      Array.prototype.forEach.call(roles, function (role) {
        var node = role.getBoundingClientRect().top + 34;
        role.style.setProperty('--past', clamp((line - node) / 70, 0, 1).toFixed(3));
      });
    }

    function onScroll() {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(update);
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    update();
  })();

  /* ── 7. Tinta que sigue al cursor en las tarjetas ───────────────────── */

  (function cardInk() {
    if (reduced) return;
    document.querySelectorAll('[data-card]').forEach(function (card) {
      var pending = false;
      var last = null;
      card.addEventListener('pointermove', function (event) {
        if (event.pointerType === 'touch') return;
        last = event;
        if (pending) return;
        pending = true;
        requestAnimationFrame(function () {
          pending = false;
          var rect = card.getBoundingClientRect();
          card.style.setProperty('--mx', (((last.clientX - rect.left) / rect.width) * 100).toFixed(1) + '%');
          card.style.setProperty('--my', (((last.clientY - rect.top) / rect.height) * 100).toFixed(1) + '%');
        });
      }, { passive: true });
    });
  })();
})();
