# Handoff: Portfolio — Diego Pardo Montero

## Overview
Single-page bilingual (EN default / ES) portfolio for a Data Engineer. Seven numbered sections under a newspaper-style masthead: 01 About · 02 Experience · 03 Education · 04 Skills · 05 Case studies · 06 Independent work · 07 Contact. Content source of truth: `portafolio-spec-contenido.md` (Spanish); the EN/ES copy actually used lives in the `T`, `EXP`, `CERTS`, `SERVICES`, `STAGES`, `BEYOND` and `CASES` objects inside the design file's script.

## About the Design Files
The files in this bundle are **design references built in HTML** — a prototype showing the intended look, copy and behaviour, not production code to copy verbatim. Recreate it in the target codebase's environment (Astro, Next.js, plain HTML/CSS, etc.) using its own patterns. If no stack exists yet, a static-site setup (Astro or plain HTML + CSS) is the natural fit: no backend, one page, two languages.

`Portafolio - Diego Pardo.dc.html` uses a proprietary component runtime (`<x-dc>`, `{{ }}` holes, `<sc-for>`, a `Component` class) — read it for structure, inline styles and copy; do not try to run it outside its original host. `styles.css` is the Broadsheet design-system stylesheet the page relies on: tokens (`:root` vars), base type and the `.btn`, `.tag`, `.card` classes. It is plain CSS and can be reused as-is.

## Fidelity
**High-fidelity.** Colors, type, spacing and copy are final. Recreate pixel-close at a 1180px max content width; responsive behaviour below ~1000px is not designed yet (see Responsive).

## Global layout
- Page background `var(--color-bg)` #f3f2f2, text `var(--color-text)` #201e1d, font Source Serif 4 everywhere (headings weight 600, body 400, true italic for emphasis). Load from Google Fonts: `Source+Serif+4:ital,opsz,wght@0,8..60,300..900;1,8..60,300..900`.
- Container: `max-width: 1180px; margin: 0 auto; padding: 28px 40px 80px`; sections stacked with `gap: 120px`.
- Every section (01–07) is a 2-column grid `220px 1fr`, `gap: 48px`, with `border-top: 1px solid var(--color-text); padding-top: 20px`.
  - Left rail: section numeral (`font-size: 56px; font-weight: 600; line-height: 1; color: var(--color-accent)` #0088b0) over a small-caps label (`11–12px; letter-spacing: .12em; uppercase; color: var(--color-neutral-600)`).
  - Right: section content.
- "Kicker" label style reused everywhere: `font-size: 11px; letter-spacing: .12em; text-transform: uppercase; color: var(--color-neutral-600)`.
- Links: `color: var(--color-accent-700)` #006786, no underline; hover `var(--color-accent-600)` + underline (offset 4px). Focus: `outline: 2px solid var(--color-accent); outline-offset: 2px`.

## Screens / Views (single page)

### Masthead + Hero
- Rule pair: `border-top: 4px solid #201e1d; border-bottom: 1px solid #201e1d; padding: 12px 0`. Left: nav links (About, Experience, Education, Skills, Case studies, Contact; 15px, text color, gap 28px). Right: italic dateline "Bogotá, Colombia" (neutral-600) and an EN / ES switch (13px, uppercase, letter-spacing .08em; active = accent-700 weight 600, inactive = neutral-500).
- Hero grid `1fr 340px`, gap 72px, `align-items: end`, `padding-top: 64px`.
  - Left: name in small caps (16px, .08em, neutral-700) → `<h1>` "Data / Engineer" at `128px; line-height .92; letter-spacing -.03em; weight 600` → subtitle 22px / 1.4, max-width 640px → row (gap 18px): `.btn.btn-primary` "Download CV" + underlined links LinkedIn, GitHub, diegopardomontero@gmail.com.
  - Right: spec grid (2×2, `border-top: 1px solid text; padding-top 12px`; kicker + 14px value): Location "Bogotá, Colombia" · Mode "Hybrid / Remote" · Experience "3 years" · Certifications "AWS · Google Cloud · +40 more". Below, 15px/1.5 bio in neutral-800.

### 01 About
- Lead paragraph `28px / 1.3, weight 600, letter-spacing -.01em, max-width 820px`.
- Three columns (`repeat(3, 1fr)`, gap 32px, 16px/1.5): kicker + text — What I do · Background · Looking for.

### 02 Experience
- List of `<article>` rows: grid `200px 1fr`, gap 32px, `padding: 28px 0; border-top: 1px solid var(--color-neutral-300)`.
  - Left 14px: dates (text color) + italic place (neutral-700).
  - Right: `<h3>` 26px/1.15 weight 600 "Role — Company" (company in neutral-600 weight 400) → bullets `<ul>` 16px/1.5 gap 8px → stack line 14px neutral-700.
- Final compact row (teaching assistant): same grid, 14px neutral-700, no bullets.

### 03 Education
- Two columns 1fr 1fr, gap 48px. Left: university `<h3>` 30px, degree line 16px, details 15px/1.6 neutral-800; Languages kicker + value. Right: Certifications kicker → list rows (15px, `padding 9px 0; border-top 1px solid neutral-300`, name left / meta right in neutral-600) → `.tag.tag-accent-2` "In progress" + text → italic link "+40 additional certifications — see LinkedIn".

### 04 Skills
- Left rail also carries a 14px/1.6 legend (neutral-700).
- Block "The pipeline": grid `minmax(0,1fr) 20px ×5` alternating stage / arrow. Arrow = "→" 18px in accent, `padding-top 6px`, centered. Stage = 28px duotone icon (fill layer at 20% opacity + solid path, color accent) → name 19px weight 600 → core tools 15px/1.6 (text color) → secondary tools 14px/1.5 neutral-600. Stages: Sources · Processing · Modelling · Orchestration · Quality & ops.
- Block "Around the pipeline": 3 columns, each `28px 1fr` grid with icon (neutral-700) + name/core/italic more. Items: Backend · Cloud · Studied, not yet in production.
- Icons: Phosphor Icons, **duotone** weight (Database, Cpu, Stack, FlowArrow, ShieldCheck, Code, Cloud, BookOpen). Use the official Phosphor package rather than the inline paths in the file.

### 05 Case studies
- 3 equal `.card` articles (`repeat(3, 1fr)`, gap 24px, `align-items: stretch`; card is flex column, gap 14px, height 100%). Inside: `.card-kicker`, `.card-title` (24px/1.15), `.card-body` (15px/1.55), `.card-meta` with `.tag.tag-neutral` chips pinned to the bottom (`margin-top: auto`).

### 06 Independent work
- `<h2>` 40px/1.1 weight 600 max-width 720px → grid 3 columns (gap 32px 36px): five services (name 20px weight 600 + 16px description in neutral-800) and a sixth cell with the italic modality line (14px neutral-600). **Business caveat**: this section may need to be removed if an exclusivity clause applies — keep it easy to drop.

### 07 Contact
- `<h2>` 56px/1, letter-spacing -.03em, max-width 820px → 18px/1.5 body (neutral-800, max-width 620px) → 3-column auto grid (gap 16px 48px): Email / Phone (+57 302 306 3447, `tel:+573023063447`) / Profiles → button row: `.btn.btn-primary` "Write me" (mailto) + `.btn.btn-secondary` "Download CV".
- Footer: `border-top: 4px solid text; padding-top 12px`, 13px neutral-600, name left / italic "Bogotá, Colombia · 2026" right.

## Interactions & Behavior
- EN/ES toggle swaps every string on the page (nav, hero, all sections, footer). Persist choice in `localStorage` key `dpm-portfolio-lang`; default `en`. Also acceptable: `/` and `/es` routes.
- Nav links are in-page anchors (#about, #experience, #education, #skills, #work, #contact); smooth scroll optional.
- Buttons/tags/cards use the stylesheet's built-in hover/pressed/focus states — do not restyle.
- No animations.
- Buttons must never wrap: `white-space: nowrap; flex: none`.

## Responsive
Designed at ≥1180px content width. Not yet designed below ~1000px; recommended collapse: section grids to a single column (rail above content), hero to one column with `<h1>` ~72px, pipeline to a vertical list with "↓" arrows, cards to one column.

## Placeholders to replace
- LinkedIn and GitHub hrefs (currently root URLs).
- "Download CV" href (currently `#contact` / `#`) → the CV PDF.

## Design Tokens (from styles.css)
- Colors: bg #f3f2f2 · surface #eae9e9 · text #201e1d · accent #0088b0 (600 #1186ac, 700 #006786) · accent-2 #d6006c · process-yellow #edbb00 · neutral 300 #d7d3d3, 500 #9b9797, 600 #7d7979, 700 #605d5d, 800 #444141.
- Type: Source Serif 4 (heading weight 600). Sizes used: 11, 12, 13, 14, 15, 16, 18, 19, 20, 22, 24, 26, 28, 30, 40, 56, 128px.
- Spacing scale: 5 / 10 / 15 / 20 / 30 / 40px (`--space-1…8`); layout gaps used: 48, 72, 120px.
- Radius: 1 / 2 / 4px. Shadows: `--shadow-sm/md/lg` (see stylesheet).

## Assets
- Fonts: Source Serif 4 (Google Fonts).
- Icons: Phosphor duotone (phosphoricons.com).
- No images.

## Files
- `Portafolio - Diego Pardo.dc.html` — the design (structure, inline styles, all EN/ES copy in the script's data objects).
- `styles.css` — Broadsheet design-system stylesheet (tokens + .btn/.tag/.card). Reusable as-is.
- `portafolio-spec-contenido.md` — original content specification (Spanish).
