# Portafolio — Especificación de contenido
**Diego Pardo Montero** · Documento base para diseño y construcción

---

## 1. Posicionamiento

**Titular principal**
> Data Engineer

**Subtitular**
> Diseño, construyo y opero pipelines y arquitecturas de datos en producción para entornos empresariales y financieros. Ingeniero de Sistemas con base sólida en backend, cloud y sistemas distribuidos.

**Bio corta (para el hero, ~50 palabras)**
> Ingeniero de Sistemas de la Pontificia Universidad Javeriana con tres años construyendo y operando plataformas de datos: frameworks de migración a gran escala, arquitecturas Medallion, pipelines ETL/ELT y respuesta a incidentes en producción. Certificado por AWS y Google. Bogotá, Colombia — disponible para trabajo híbrido y remoto.

**Bio larga (sección "Sobre mí", ~150 palabras)**
> Ingeniero de Sistemas de la Pontificia Universidad Javeriana con tres años de experiencia diseñando, construyendo y operando plataformas de datos en entornos empresariales y de servicios financieros.
>
> En Diametral desarrollé un framework en Python para migraciones Oracle a gran escala, con definiciones declarativas en YAML y SQL, múltiples estrategias de carga y control de concurrencia, y opero pipelines de producción sobre una arquitectura Medallion. En Globant optimicé procesos ETL en Python y SQL e implementé validaciones automatizadas de calidad de datos sobre conjuntos productivos. En Pacífico Emprende trabajé en la intersección entre datos y backend: modelado relacional en MySQL y desarrollo de servicios en Java y Spring para una plataforma con más de 200 usuarios.
>
> Mi perfil combina ingeniería de datos, desarrollo backend y arquitecturas distribuidas, respaldado por certificaciones de AWS y Google Cloud. Trabajo desde Bogotá en modalidad híbrida o remota.

---

## 2. Roles para los que eres creíble

Orden de fuerza según la evidencia real:

1. **Data Engineer** — núcleo, tres años, múltiples empleadores
2. **Analytics Engineer / Data Platform Engineer** — modelado dimensional, SCD, Medallion, Trino
3. **Backend / Software Engineer** — Java, Spring Boot, APIs, microservicios, dos años en Pacífico Emprende
4. **Cloud Engineer** — con matiz: certificado en AWS y GCP, uso profesional en GCP, IBM Cloud y Azure Databricks, pero sin evidencia de infraestructura como código ni administración de plataforma. Aplicable a roles junior/mid de cloud, no a SRE ni platform engineering senior

**Regla de oro:** un solo titular en el sitio. La versatilidad se demuestra en los case studies, no acumulando cargos en el header.

---

## 3. Habilidades por nivel

### Nivel 1 — Producción sostenida
Uso continuo en entornos empresariales, en más de un empleador.

`Python` · `SQL` · `PySpark / Apache Spark` · `Oracle Database` · `Snowflake` · `Airflow` · `Starburst / Trino` · `ETL / ELT` · `Modelado dimensional (SCD Tipo 2)` · `Arquitectura Medallion` · `Calidad y validación de datos` · `Gestión de incidentes y RCA` · `Git / GitHub` · `Linux` · `Bash`

### Nivel 2 — Uso profesional
Aplicado en trabajo real, en alcance más acotado.

`Java` · `Spring / Spring Boot` · `Docker` · `PostgreSQL` · `MySQL` · `PL/SQL` · `Databricks / Azure Databricks` · `GCP` · `AWS` · `IBM Cloud` · `Azure Data Factory` · `Pandas` · `NumPy` · `TypeScript` · `Angular` · `Django` · `PHP` · `REST APIs` · `CI/CD` · `Agile / Scrum`

### Nivel 3 — Certificación, docencia y proyectos
Conocimiento fundamentado sin haberlo operado en producción.

`Kubernetes / GKE` · `Apache Kafka` · `Microservicios` · `Serverless` · `React` · `Machine Learning` · `Node.js` · `JavaScript` · `GraphQL` · `C#` · `C++` · `Kotlin` · `Postman / Swagger` · `Arquitectura de software` · `Sistemas distribuidos`

> **Nota de honestidad:** este esquema te protege. Si alguien pregunta por algo del Nivel 3, la respuesta correcta —"lo estudié y lo apliqué en un proyecto, no lo he operado en producción"— ya está implícita en cómo lo presentaste. Eso genera confianza en vez de exponerte.

---

## 4. Experiencia

### Data Engineer — Diametral
*Abr 2026 – Presente · Bogotá, híbrido*

- Framework en Python dirigido por configuración para migraciones Oracle a gran escala: definiciones declarativas en YAML y SQL, múltiples estrategias de carga (catálogo, SCD Tipo 2, hechos, agregados), auditoría y control de concurrencia
- Scheduler dirigido por tabla de control y módulo de reportería para observabilidad de pipelines, orquestando ciclos batch diarios y semanales sobre arquitectura Medallion con PySpark y Starburst
- Monitoreo y resolución de incidentes de punta a punta en servicios financieros: análisis de causa raíz, correcciones permanentes y documentación, en coordinación con DBA y DevOps

`Python` `SQL` `PySpark` `Oracle` `Starburst/Trino` `Airflow` `GCP` `Databricks` `IBM Cloud`

### Data Engineer Jr. Advanced — Globant
*Ago 2025 – Abr 2026 · Bogotá, híbrido*

- Optimización de pipelines ETL y flujos de backend en Python y SQL, con reducción de ~20% en tiempos de ejecución
- Validaciones y controles de calidad automatizados que redujeron la verificación manual en 65%
- Resolución de ~7 incidentes de producción diarios dentro de SLA, con análisis de causa raíz

`Python` `SQL` `Java` `Spring` `AWS` `Docker` `Angular` `TypeScript` `Linux` `Bash`

### Information Technology Trainee — Globant
*Ene 2025 – Jul 2025 · Bogotá*

- Mantenimiento y depuración de pipelines en Snowflake y Airflow, con 25% menos fallos de jobs
- Scripts de validación en Python para detectar discrepancias en datasets de miles de registros
- Automatización de procesos recurrentes, ahorrando 6–8 horas semanales de trabajo manual

`Python` `SQL` `Snowflake` `Airflow` `Spark` `Java` `Docker`

### Data Engineer — Pacífico Emprende
*Ene 2023 – Dic 2024 · Remoto*

> Rol mixto de ingeniería de datos y desarrollo de software. Es tu mejor evidencia del ángulo de software engineer, así que los bullets deben mostrar ambas caras.

- Modelos de datos relacionales en MySQL para una plataforma con más de 200 usuarios, mejorando consistencia, integridad y rendimiento
- Servicios backend construidos desde cero en Java y Spring, con optimización de consultas que redujo tiempos de carga ~20%

`Java` `Spring Boot` `MySQL` `SQL` `PHP` `Django` `WordPress`

### Monitor Académico — Pontificia Universidad Javeriana
*Ene 2022 – May 2024*

> Entrada compacta, al final de la línea de tiempo y con menor peso visual que los roles profesionales. Una sola línea, sin bullets.

Monitor en Sistemas Distribuidos, Estructuras de Datos e Introducción a la Programación.

`Java` `Estructuras de datos` `Sistemas distribuidos` `Git`

---

## 5. Case studies

### Principal — Framework de migración de datos a gran escala
*Diametral · 2026*

El más fuerte que tienes: es arquitectura, no uso de herramientas.

- **Problema:** migrar volúmenes grandes desde Oracle con múltiples patrones de carga, sin reescribir código para cada tabla
- **Solución:** framework dirigido por configuración — el ingeniero declara la tabla en YAML y SQL, el framework resuelve la estrategia, la auditoría y la concurrencia
- **Arquitectura:** diagrama del flujo Medallion (Bronze/Silver/Gold) con PySpark y Starburst, más el scheduler por tabla de control
- **Decisiones de diseño:** por qué declarativo y no imperativo; cómo se maneja SCD Tipo 2; qué se audita y por qué
- **Resultado:** ciclos batch diarios y semanales en producción

> **Alcance publicable:** el trabajo técnico sí se puede contar; el cliente no. Describe la arquitectura, las decisiones de diseño y los patrones con todo el detalle que quieras, refiriéndote al contexto como "un cliente de servicios financieros". Fuera: nombre del cliente, nombres de esquemas y tablas reales, capturas de entornos y cualquier dato que permita identificarlo.

### Secundario — Enseñarte
*Tesis con honores · 5.0/5.0 · 2025*

Ángulo distinto: impacto social, ML, y una nota máxima que respalda la calidad.

- Prototipo funcional para la enseñanza, aprendizaje y evaluación de Lengua de Señas Colombiana (LSC)
- Modelo de datos y pipeline para capturar, almacenar y evaluar datos de progreso
- `Python` `React` `SQL` `Machine Learning`

### Terciario — Plataforma e-commerce con microservicios
*Proyecto personal · 2024*

Va tercero o en "Otros proyectos". Es un proyecto común de portafolio y compite con tu experiencia real.

- Arquitectura de microservicios con patrón base-de-datos-por-servicio
- Comunicación orientada a eventos, contenedores Docker, APIs REST
- `Java` `Spring Boot` `Docker` `PostgreSQL` `Kafka`

---

## 6. Formación y credenciales

**Pontificia Universidad Javeriana** — Ingeniería de Sistemas, 2021–2025
Promedio 4.4/5.0 · Tesis con honores 5.0/5.0 · Doble énfasis
8 reconocimientos de excelencia académica
ACM Javeriana (Senior, 2020–2022) · IEEE RAS Javeriana

**Certificaciones a destacar (máximo 10 en el sitio)**

- AWS Certified Solutions Architect – Associate (Dic 2025)
- AWS Certified Cloud Practitioner (Jul 2024)
- Google Cloud Digital Leader (Abr 2025)
- Google — Architecting with GKE: Foundations
- IBM — Application Development using Microservices and Serverless
- Meta — Introduction to Databases
- HackerRank — SQL (Intermediate), Java
- Tecnológico de Monterrey — Gestión de proyectos
- **En curso:** Databricks Data Engineer Associate · Snowflake SnowPro Core

Cierra con: *"+40 certificaciones adicionales — ver LinkedIn"*. No listes los cursos introductorios de 2021–2022.

**Idiomas**
Español (nativo) · Inglés C1 — Professional Working Proficiency

---

## 7. Estructura del sitio

1. **Hero** — nombre, titular, subtitular, ubicación, enlaces (LinkedIn, GitHub, correo), botón de descarga del CV
2. **Sobre mí** — bio larga
3. **Case studies** — tres, con el de Diametral primero y con más profundidad
4. **Experiencia** — línea de tiempo, incluyendo la monitoría académica
5. **Habilidades** — los tres niveles, visualmente diferenciados
6. **Formación y certificaciones** — curadas
7. **Contacto** — ver nota sobre consultoría abajo

**Idioma:** inglés como principal, con opción de español. Te abre el mercado remoto internacional sin cerrar el colombiano — en tecnología en Colombia el inglés no es barrera para quien contrata.

---

## 8. Servicios de consultoría

Sección propia, después de los case studies y antes de contacto.

**Encabezado:** Trabajo independiente

**Servicios**

- **Arquitectura de datos** — diseño de modelos dimensionales, estrategias SCD y arquitecturas por capas (Bronze/Silver/Gold)
- **Construcción de pipelines** — procesos ETL/ELT en Python, SQL y PySpark, con orquestación y observabilidad
- **Migraciones de datos** — diseño y ejecución de migraciones a gran escala entre sistemas relacionales y plataformas analíticas
- **Calidad de datos** — implementación de validaciones automatizadas y controles de consistencia sobre entornos productivos
- **Auditoría técnica** — revisión de pipelines existentes, identificación de cuellos de botella y plan de remediación

**Modalidad:** remoto · proyectos puntuales o acompañamiento continuo

> **Pendiente de verificar:** estar vinculado a una consultora y ofrecer servicios independientes en paralelo puede chocar con cláusulas de exclusividad o no competencia. Es una cuestión distinta del NDA. Si al revisar el contrato aparece alguna restricción, reemplaza esta sección por un "Contacto" neutro que no anuncie servicios — pierdes poco, porque quien quiera contratarte escribe igual.

---

## 9. Pendientes antes de diseñar

- [ ] Revisar cláusulas de exclusividad / no competencia con Diametral (ver sección 8)
- [ ] Actualizar GitHub — queda enlazado en el sitio
- [ ] Agregar la monitoría académica al CV, en formato compacto
- [x] Nivel de inglés: C1 — Professional Working Proficiency
- [x] Alcance publicable del proyecto de Diametral: trabajo técnico sí, cliente no
- [x] Headline de LinkedIn corregido
