/**
 * Comportamiento del portafolio. Todo es progresivo: sin JavaScript la
 * página se ve y se navega igual, sólo sin movimiento.
 *
 *   1. Intro de marca: el logo se dibuja y vuela a la cabecera (una vez
 *      por sesión), luego suelta la entrada del hero.
 *   2. Progreso de lectura en el filete de la cabecera.
 *   3. Recuerda el idioma elegido y funde el cambio de página.
 *   4. Marca en el menú la sección que se está leyendo.
 *   5. Entrada suave de cada sección al aparecer.
 *
 * Las escenas animadas viven aparte, en motion.js. Ambos exponen
 * window.DPM.site(root) / window.DPM.motion(root) y se inician solos salvo
 * que window.DPM_MANUAL esté puesto (para embeberlos en otra página).
 */
(function () {
  'use strict';
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var KEY = 'dpm-portfolio-lang';
  var INTRO_KEY = 'dpm-intro-seen';

  function site(root) {
    root = root || document;
    document.documentElement.classList.add('js');

    /* ── 1. Intro ─────────────────────────────────────────────────── */
    (function intro() {
      var overlay = root.querySelector('[data-intro]');
      var body = document.body;
      var target = root.querySelector('.brand-mark');
      var seen = false;
      try { seen = sessionStorage.getItem(INTRO_KEY) === '1'; } catch (e) {}
      if (!overlay || !target || seen || reduced) {
        if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
        body.classList.add('is-ready');
        return;
      }
      try { sessionStorage.setItem(INTRO_KEY, '1'); } catch (e) {}
      body.classList.add('has-intro');
      var logo = overlay.querySelector('.intro-logo');
      setTimeout(function () {
        var from = logo.getBoundingClientRect();
        var to = target.getBoundingClientRect();
        var s = to.width / from.width;
        logo.style.transition = 'transform .7s cubic-bezier(.65, 0, .35, 1)';
        logo.style.transform = 'translate(' + (to.left - from.left).toFixed(1) + 'px, ' + (to.top - from.top).toFixed(1) + 'px) scale(' + s.toFixed(4) + ')';
        overlay.classList.add('is-flying');
        body.classList.add('is-ready');
        setTimeout(function () {
          body.classList.remove('has-intro');
          if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
        }, 760);
      }, 1350);
    })();

    /* ── 2. Progreso de lectura ───────────────────────────────────── */
    (function progress() {
      var html = document.documentElement;
      var ticking = false;
      function update() {
        ticking = false;
        var max = html.scrollHeight - window.innerHeight;
        html.style.setProperty('--scroll', max > 0 ? Math.min(1, window.scrollY / max).toFixed(4) : '0');
        html.classList.toggle('is-scrolled', window.scrollY > 40);
      }
      function onScroll() { if (ticking) return; ticking = true; requestAnimationFrame(update); }
      window.addEventListener('scroll', onScroll, { passive: true });
      window.addEventListener('resize', onScroll);
      update();
    })();

    /* ── 3. Idioma ────────────────────────────────────────────────── */
    root.querySelectorAll('.lang-link').forEach(function (link) {
      link.addEventListener('click', function (event) {
        try { localStorage.setItem(KEY, link.dataset.lang); } catch (e) {}
        /* Sin View Transitions, el fundido lo hace la página al salir. */
        if (document.startViewTransition || reduced || event.metaKey || event.ctrlKey) return;
        event.preventDefault();
        document.body.classList.add('is-leaving');
        setTimeout(function () { window.location.href = link.href; }, 230);
      });
    });

    /* ── 4. Sección activa en el menú ─────────────────────────────── */
    (function navHighlight() {
      var links = {};
      root.querySelectorAll('[data-nav]').forEach(function (a) { links[a.dataset.nav] = a; });
      var sections = root.querySelectorAll('.section[id]');
      if (!sections.length || !('IntersectionObserver' in window)) return;
      var visible = new Set();
      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) visible.add(entry.target.id); else visible.delete(entry.target.id);
        });
        var current = null;
        sections.forEach(function (s) { if (visible.has(s.id) && !current) current = s.id; });
        Object.keys(links).forEach(function (id) {
          if (id === current) links[id].setAttribute('aria-current', 'location');
          else links[id].removeAttribute('aria-current');
        });
      }, { rootMargin: '-45% 0px -50% 0px' });
      sections.forEach(function (s) { observer.observe(s); });
    })();

    /* ── 5. Entrada al aparecer ───────────────────────────────────── */
    (function reveal() {
      var targets = root.querySelectorAll('[data-reveal]');
      if (!('IntersectionObserver' in window)) {
        targets.forEach(function (el) { el.classList.add('is-visible'); });
        return;
      }
      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        });
      }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
      targets.forEach(function (el) { observer.observe(el); });
    })();
  }

  window.DPM = window.DPM || {};
  window.DPM.site = site;
  if (!window.DPM_MANUAL) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { site(); });
    else site();
  }
})();
